number_secret = 123
answer = int(input("adivine el numero, solo tiene un intento"))
if answer == number_secret:
    print("Acertaste")
else:
    print("Suerte para la proxima , aunke no hay proxima")    