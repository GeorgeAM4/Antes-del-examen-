print("Para calcular el indice de masa corporal agrege los siguientes datos: peso, altura")
peso = float(input())
altura = float(input())
imc = peso / altura**2
if imc < 18.5:
    print("Su IMC es bajo")
elif imc>18.5 and imc < 24.9:
    print("Su IMC es normal")     
else:
    print("Su IMC es alto(sobrepeso)")    
    print(imc)