print("clasificar notas del 0-100 en A, B, C, D, o F")
note = float(input("Ingrese su nota porfavor: "))
if note == 0:
    print("Su nota no puede ser nagativa")
elif note > 100:
    print("Su nota no puede ser mayor a 100")
elif note >=0 and note <=20:
    print("Usted tiene una F")        
elif note >=21 and note <=40:
    print("Usted tiene una D")
elif note >=41 and note <=60:
    print("Usted tiene una C")
elif note >=61 and note <=80:
    print("Usted tiene una B")
else:   
    print("Usted tiene una A")
