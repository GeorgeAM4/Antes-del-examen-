password = "mantequilla"
password_1 = str(input("Ingrese su contraseña con mas de 8 caracteres: "))
caracteres = len(password_1)
if caracteres <=8:
    print("Su contraseña no tiene mas de 8 caracateres ")
elif password_1 == password:
    print("Contraseña correcta") 
else:
    print("contraseña incorrecta")           