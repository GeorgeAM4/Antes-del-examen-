a = int(input("elija su operacion: suma(1), resta(2), multiplicacion(3), divicion(4): "))
b = float(input("Ingrese su prime numero: "))
c = float(input("Ingrese su segundo numero: "))
if a == 1:
    print("El resultado de su suma es: ",b+c)
elif a == 2:
    print("El resultadi de su resta es: ".b-c)
elif a== 3:
    print("El resultado de su multiplicacion es: ", b*c)
elif a == 4:
    print("El resultado de su division es: ", b / c)
else:
    print("No seleciono ninguna de las opciones de operacion")    