note =float(input("Ingrse se su nota porfavor: "))
if note > 60:
    print("Aprobado")
else:
    print("Reprobado")    