print("Comparacion de numeros, ingrese sus numeros: ")
a= float(input())
b= float(input())
if a == b :
    print("Sus numeros son iguales")
elif a<b:
    print("El segundo numero es mayor que el primero")
else:
    ("El primer numero es mayor que el suegundo")        