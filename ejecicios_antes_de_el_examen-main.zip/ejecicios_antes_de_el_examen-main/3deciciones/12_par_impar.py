number = int(input("Porfavor, ingrese un numer sin decimales: "))
if number % 2 :
    print("Su numero es impar")
else:
    print("Su numero es par")    