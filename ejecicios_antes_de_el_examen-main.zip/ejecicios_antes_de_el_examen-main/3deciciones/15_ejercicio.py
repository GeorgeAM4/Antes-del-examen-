number=float(input("Escribir un algoritmo que detece si un numero es positivo o negativo, ingrese su numero: "))
if number == 0:
    print("Su numero es cero asi que quien sepa si es negativo o positivo etc.")
elif number < 0:
    print("Su numero es nagativo")
else:
    print("Su numero es positivo")         