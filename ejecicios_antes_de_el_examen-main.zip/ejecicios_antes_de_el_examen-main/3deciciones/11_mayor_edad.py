age =int(input("Prfavor ingree su edad: "))
if age >=18 :
    print("Puedes pasar")
else:
    print("Acceso denegado")    