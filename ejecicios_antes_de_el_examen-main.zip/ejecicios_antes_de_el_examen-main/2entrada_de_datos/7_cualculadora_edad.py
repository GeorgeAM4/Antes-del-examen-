year = int(input("Ingrese su año de nacimiento prfvor:"))
age = 2026 - year
print("Su edad es:", age )
