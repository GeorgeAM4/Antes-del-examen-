word = str(input("Ingrese una frase por favor: "))
characters=len(word)
print("Su frase tiene",characters,"caracteres")