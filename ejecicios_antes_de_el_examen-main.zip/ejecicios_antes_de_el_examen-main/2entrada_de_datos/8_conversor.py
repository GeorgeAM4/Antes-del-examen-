pesos= float(input("Convercion de pesos a dolares (0.58), ingrese sus pesos"))
print("Sus pesos añ cambio de dolar son:", pesos*0.58,"$")