user = str(input("Ingrese su nombre de usuario porfavor: "))
print("Muchos gusto en conocerte",user)