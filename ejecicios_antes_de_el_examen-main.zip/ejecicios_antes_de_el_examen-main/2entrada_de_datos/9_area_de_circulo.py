radio = float(input("Para calcular el area de un circulo ingrese sus radio porfavor: "))
area = (3.1416*radio**2)
print("El area de este circulo es:",area)