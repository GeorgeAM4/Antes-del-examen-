name = "Eduardo"
age ="20"
print(name, age)