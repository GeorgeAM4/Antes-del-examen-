a = "Aprendiendo"
b= "Python"
print(a, b)