side = float(input("Ingrese uno de los lados de su cuadrado en cm: "))
area = side**2
print("El area de su cuadrado es:",area,"cm")
