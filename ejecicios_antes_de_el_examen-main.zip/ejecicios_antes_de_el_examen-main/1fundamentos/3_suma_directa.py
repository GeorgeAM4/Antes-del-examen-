
a = int(input("ingrese su primer numero:"))
b = int(input("ingrese su segundo numero:"))
print("El resultado de la sumas es:",a+b)