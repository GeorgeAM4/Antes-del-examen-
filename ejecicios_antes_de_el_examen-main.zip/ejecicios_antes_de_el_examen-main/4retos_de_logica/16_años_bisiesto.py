year = int(input("para saber si un año es bisiesto, porfavor ingrese un año: "))
if year/4 or year/400:
    print("Su año es bisiesto")
else:
    print("Su año no es bisiesto")    