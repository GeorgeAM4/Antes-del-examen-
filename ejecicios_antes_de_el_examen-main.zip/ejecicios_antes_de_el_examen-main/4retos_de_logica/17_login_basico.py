user= "admin"
pin = 1234
print("Ingrese su userai y su clave en ese orden porfavor: ")
user_1=str(input())
pin_1 = int(input())
if user == user_1 and pin == pin_1:
    print("Acceso permitido")
else:
    print("Acceso denegado")    