number = float(input("porfavor ingrese un numero para saber si esta dentro del rango del 1 a 100"))
if number == 1:
    print("su numero es el 1")
elif number == 100:
    print("su numero es el 100")
elif number>1 and number <100:
    print("su numero esta dentro del rango del 1 al 100")        
else:
    print("su numero no esta dentro del rango del 1 al 100")    