money = float(input("Para saber si tiene descuento ingrese la cantidad de su compra: "))
if money > 100:
    descuento = money * 0.10
    print("Usted tiene un descuento del 10% su monto a pagar es:", descuento)
else:
    print("Usted no tiene descuento, su monto a pagar es: ", money)    