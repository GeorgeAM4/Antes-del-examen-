print(input("Ingrese tres lados para saber si se puede formar un triangulo"))
a = float(input())
b = float(input())
c = float(input())
if (a + b) > c:
    print("si se puede formar un triangulo XD")
else:
    print("no se puede formar un triangulo XC")    